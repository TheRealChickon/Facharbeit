package passwordmanager;

public class PasswordManager extends Login {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Login.main(args);
    }

}
